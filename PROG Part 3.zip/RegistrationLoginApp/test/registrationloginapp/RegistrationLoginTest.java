package registrationloginapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RegistrationLoginTest {

    @Test
    public void testMessageID() {
        Messages messages = new Messages(new java.util.Scanner(""));
        assertTrue(messages.checkMessageID("1234567890"));
        assertFalse(messages.checkMessageID("12345"));
    }

    @Test
    public void testRecipientNumber() {
        Messages messages = new Messages(new java.util.Scanner(""));
        assertTrue(messages.checkRecipientCell("+27834557896"));
        assertFalse(messages.checkRecipientCell("0834557896"));
    }

    @Test
    public void testMessageHash() {
        Messages messages = new Messages(new java.util.Scanner(""));
        String hash = messages.createMessageHash("1234567890", 1, "Did you get the cake?");
        assertEquals("12:1:DID CAKE?", hash);
    }

    @Test
    public void testUsername() {
        RegistrationLogin user = new RegistrationLogin(new java.util.Scanner(""));
        assertTrue(user.checkUserName("ab_cd"));
        assertFalse(user.checkUserName("abcdef"));
    }

    @Test
    public void testPassword() {
        RegistrationLogin user = new RegistrationLogin(new java.util.Scanner(""));
        assertTrue(user.checkPasswordComplexity("Hello123!"));
        assertFalse(user.checkPasswordComplexity("hello"));
    }
}
