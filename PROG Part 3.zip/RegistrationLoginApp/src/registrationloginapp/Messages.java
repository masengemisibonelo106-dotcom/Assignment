package registrationloginapp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Messages {

    private Scanner input;
    private Random random;

    // Arrays used to keep the messages
    private Message[] sentMessages = new Message[100];
    private Message[] disregardedMessages = new Message[100];
    private Message[] storedMessages = new Message[100];

    private String[] messageHashes = new String[100];
    private String[] messageIDs = new String[100];

    private int sentCount = 0;
    private int disregardedCount = 0;
    private int storedCount = 0;
    private int allMessageCount = 0;
    private int totalMessagesSent = 0;

    private String sender = "08388884567";

    public Messages() {
        this(new Scanner(System.in));
    }

    public Messages(Scanner input) {
        this.input = input;
        random = new Random();
        loadMessages();
    }

    public void start() {
        int option = 0;

        while (option != 3) {
            System.out.println("\nWelcome to QuickChat");
            System.out.println("1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");

            option = readInteger();

            if (option == 1) {
                sendMessages();
            } else if (option == 2) {
                printMessages();
            } else if (option == 3) {
                System.out.println("Good Bye");
                System.out.println("Total messages sent: " + returnTotalMessages());
            } else if (option == 4) {
                storedMenu();
            } else {
                System.out.println("Please choose 1, 2, 3 or 4.");
            }
        }
    }

    private int readInteger() {
        while (!input.hasNextInt()) {
            System.out.print("Please enter a number: ");
            input.nextLine();
        }

        int number = input.nextInt();
        input.nextLine();
        return number;
    }

    public void sendMessages() {
        System.out.print("How many messages would you like to send? ");
        int numberOfMessages = readInteger();

        if (numberOfMessages < 1) {
            System.out.println("Please enter at least 1 message.");
            return;
        }

        for (int i = 0; i < numberOfMessages; i++) {
            System.out.println("\nMessage " + (i + 1));
            String recipient = readRecipient();
            String messageText = readMessage();

            Message message = createMessage(recipient, messageText, i + 1);

            if (allMessageCount < messageIDs.length) {
                messageIDs[allMessageCount] = message.getMessageID();
                messageHashes[allMessageCount] = message.getMessageHash();
                allMessageCount++;
            }

            System.out.println("Message ID: " + message.getMessageID());
            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");
            System.out.print("Choose an option: ");

            int choice = readInteger();

            if (choice == 1) {
                if (sentCount < sentMessages.length) {
                    sentMessages[sentCount] = message;
                    messageHashes[sentCount] = message.getMessageHash();
                    messageIDs[sentCount] = message.getMessageID();
                    sentCount++;
                    totalMessagesSent++;
                    System.out.println("Message successfully sent.");
                    displayMessage(message);
                } else {
                    System.out.println("Message array is full.");
                }
            } else if (choice == 2) {
                if (disregardedCount < disregardedMessages.length) {
                    disregardedMessages[disregardedCount] = message;
                    disregardedCount++;
                }
                System.out.println("Message disregarded.");
            } else if (choice == 3) {
                if (storedCount < storedMessages.length) {
                    storedMessages[storedCount] = message;
                    storedCount++;
                    storeMessages();
                    System.out.println("Message successfully stored.");
                } else {
                    System.out.println("Stored messages array is full.");
                }
            } else {
                System.out.println("Invalid choice. Message was not sent.");
            }
        }

        System.out.println("Total messages sent: " + returnTotalMessages());
    }

    private String readRecipient() {
        while (true) {
            System.out.print("Enter recipient cell number (+27XXXXXXXXX): ");
            String recipient = input.nextLine();

            if (checkRecipientCell(recipient)) {
                return recipient;
            }

            System.out.println("Invalid number. Use +27 followed by 9 digits.");
        }
    }

    private String readMessage() {
        while (true) {
            System.out.print("Write your message (maximum 250 characters): ");
            String messageText = input.nextLine();

            if (messageText.length() <= 250) {
                return messageText;
            }

            System.out.println("Your message is too long. Please shorten it.");
        }
    }

    public boolean checkMessageID(String messageID) {
        return messageID != null && messageID.matches("[0-9]{10}");
    }

    public boolean checkRecipientCell(String recipient) {
        return recipient != null && recipient.matches("\\+27[6-9][0-9]{8}");
    }

    public String createMessageHash(String messageID, int messageNumber, String messageText) {
        String trimmedMessage = messageText.trim();
        String firstWord = "";
        String lastWord = "";

        if (!trimmedMessage.isEmpty()) {
            String[] words = trimmedMessage.split("\\s+");
            firstWord = words[0].toUpperCase();
            lastWord = words[words.length - 1].toUpperCase();
        }

        return messageID.substring(0, 2) + ":" + messageNumber + ":" + firstWord + " " + lastWord;
    }

    private Message createMessage(String recipient, String messageText, int messageNumber) {
        String messageID = String.format("%010d", Math.floorMod(random.nextLong(), 10000000000L));
        String messageHash = createMessageHash(messageID, messageNumber, messageText);

        return new Message(messageID, messageHash, sender, recipient, messageText);
    }

    public void displayMessage(Message message) {
        System.out.println("Message ID: " + message.getMessageID());
        System.out.println("Message Hash: " + message.getMessageHash());
        System.out.println("Sender: " + message.getSender());
        System.out.println("Recipient: " + message.getRecipient());
        System.out.println("Message: " + message.getMessageText());
    }

    public void printMessages() {
        if (sentCount == 0) {
            System.out.println("Coming Soon");
            return;
        }

        System.out.println("Recently sent messages:");
        for (int i = 0; i < sentCount; i++) {
            displayMessage(sentMessages[i]);
        }
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Fourth menu option
    public void storedMenu() {
        int choice = 0;

        while (choice != 7) {
            System.out.println("\nSTORED MESSAGES");
            System.out.println("1) Display sender and recipient");
            System.out.println("2) Display longest message");
            System.out.println("3) Search by message ID");
            System.out.println("4) Search by recipient");
            System.out.println("5) Delete by message hash");
            System.out.println("6) Display message report");
            System.out.println("7) Back to main menu");
            System.out.print("Choose an option: ");

            choice = readInteger();

            if (choice == 1) {
                displaySendersAndRecipients();
            } else if (choice == 2) {
                displayLongestMessage();
            } else if (choice == 3) {
                searchMessageID();
            } else if (choice == 4) {
                searchRecipient();
            } else if (choice == 5) {
                deleteMessage();
            } else if (choice == 6) {
                displayReport();
            } else if (choice != 7) {
                System.out.println("Please choose a number from 1 to 7.");
            }
        }
    }

    public void displaySendersAndRecipients() {
        if (storedCount == 0) {
            System.out.println("There are no stored messages.");
            return;
        }

        for (int i = 0; i < storedCount; i++) {
            System.out.println("Sender: " + storedMessages[i].getSender());
            System.out.println("Recipient: " + storedMessages[i].getRecipient());
        }
    }

    public void displayLongestMessage() {
        if (storedCount == 0) {
            System.out.println("There are no stored messages.");
            return;
        }

        int longest = 0;
        for (int i = 1; i < storedCount; i++) {
            if (storedMessages[i].getMessageText().length()
                    > storedMessages[longest].getMessageText().length()) {
                longest = i;
            }
        }

        System.out.println("Longest message:");
        System.out.println(storedMessages[longest].getMessageText());
    }

    public void searchMessageID() {
        System.out.print("Enter message ID: ");
        String id = input.nextLine();
        boolean found = false;

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageID().equals(id)) {
                System.out.println("Recipient: " + storedMessages[i].getRecipient());
                System.out.println("Message: " + storedMessages[i].getMessageText());
                found = true;
            }
        }

        if (!found) {
            System.out.println("Message ID not found.");
        }
    }

    public void searchRecipient() {
        System.out.print("Enter recipient number: ");
        String recipient = input.nextLine();
        boolean found = false;

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getRecipient().equals(recipient)) {
                System.out.println(storedMessages[i].getMessageText());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    public void deleteMessage() {
        System.out.print("Enter message hash: ");
        String hash = input.nextLine();

        for (int i = 0; i < storedCount; i++) {
            if (storedMessages[i].getMessageHash().equals(hash)) {
                String deleted = storedMessages[i].getMessageText();

                for (int j = i; j < storedCount - 1; j++) {
                    storedMessages[j] = storedMessages[j + 1];
                }

                storedCount--;
                storedMessages[storedCount] = null;
                storeMessages();
                System.out.println("Message: \"" + deleted + "\" successfully deleted.");
                return;
            }
        }

        System.out.println("Message hash not found.");
    }

    public void displayReport() {
        if (storedCount == 0) {
            System.out.println("There are no stored messages.");
            return;
        }

        System.out.println("STORED MESSAGE REPORT");
        for (int i = 0; i < storedCount; i++) {
            displayMessage(storedMessages[i]);
        }
    }

    private void storeMessages() {
        try (FileWriter writer = new FileWriter("messages.json")) {
            writer.write("[");
            for (int i = 0; i < storedCount; i++) {
                Message message = storedMessages[i];

                if (i > 0) {
                    writer.write(",");
                }

                writer.write("{");
                writer.write("\"messageID\":\"" + jsonEscape(message.getMessageID()) + "\",");
                writer.write("\"messageHash\":\"" + jsonEscape(message.getMessageHash()) + "\",");
                writer.write("\"sender\":\"" + jsonEscape(message.getSender()) + "\",");
                writer.write("\"recipient\":\"" + jsonEscape(message.getRecipient()) + "\",");
                writer.write("\"message\":\"" + jsonEscape(message.getMessageText()) + "\"");
                writer.write("}");
            }
            writer.write("]");
        } catch (IOException e) {
            System.out.println("Could not store messages.");
        }
    }

    // Reads the JSON file and puts the messages into the stored array
    private void loadMessages() {
        File file = new File("messages.json");
        if (!file.exists()) {
            return;
        }

        try {
            Scanner fileInput = new Scanner(file);
            String json = "";
            while (fileInput.hasNextLine()) {
                json = json + fileInput.nextLine();
            }
            fileInput.close();

            Pattern pattern = Pattern.compile("\\{([^}]*)\\}");
            Matcher matcher = pattern.matcher(json);

            while (matcher.find() && storedCount < storedMessages.length) {
                String item = matcher.group(1);
                String id = getJsonValue(item, "messageID");
                String hash = getJsonValue(item, "messageHash");
                String from = getJsonValue(item, "sender");
                String to = getJsonValue(item, "recipient");
                String message = getJsonValue(item, "message");

                if (from == null) {
                    from = sender;
                }

                if (id != null && hash != null && to != null && message != null) {
                    storedMessages[storedCount] = new Message(id, hash, from, to, message);
                    storedCount++;
                    if (allMessageCount < messageIDs.length) {
                        messageIDs[allMessageCount] = id;
                        messageHashes[allMessageCount] = hash;
                        allMessageCount++;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Could not read stored messages.");
        }
    }

    private String getJsonValue(String item, String key) {
        Pattern pattern = Pattern.compile("\"" + key + "\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"");
        Matcher matcher = pattern.matcher(item);

        if (matcher.find()) {
            return jsonUnescape(matcher.group(1));
        }

        return null;
    }

    private String jsonEscape(String text) {
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    private String jsonUnescape(String text) {
        return text.replace("\\\"", "\"")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
                .replace("\\t", "\t")
                .replace("\\\\", "\\");
    }
}
